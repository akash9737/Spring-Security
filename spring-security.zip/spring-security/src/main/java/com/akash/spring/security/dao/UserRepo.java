package com.akash.spring.security.dao;

import com.akash.spring.security.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo  extends JpaRepository<User,Integer> {
    User findByUsername(String username);
}
