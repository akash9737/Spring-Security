package com.akash.spring.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsPasswordService;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {


    @Autowired
    private UserDetails userDetails;
    private UserDetailsPasswordService UserDetails;


    @Bean
    public AuthenticationProvider authenticationProvider(){




        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider((UserDetailsService) UserDetails);

        daoAuthenticationProvider.setUserDetailsPasswordService(UserDetails);
        DaoAuthenticationProvider daoAuthenticationProvider1 = daoAuthenticationProvider;

        daoAuthenticationProvider.setPasswordEncoder(new BCryptPasswordEncoder());
        return daoAuthenticationProvider1;

    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception{

        httpSecurity.csrf(customized->customized.disable());
        httpSecurity.authorizeHttpRequests(request->request.anyRequest().authenticated());
        httpSecurity.formLogin(Customizer.withDefaults());
        httpSecurity.httpBasic(Customizer.withDefaults());
        return httpSecurity.build();


    }


    @Bean
    public AuthenticationManager authenticationManager(AuthenticationManager config){
        return config.authenticate();
    }

    @Bean
    public UserDetailsService userDetailsService(){

        UserDetails user = User.withDefaultPasswordEncoder().username("akash").password("@123").roles("USER").build();

        UserDetails admin  = User.withDefaultPasswordEncoder().username("admin").password("admin@123").roles("ADMIN").build();

        return new InMemoryUserDetailsManager(user,admin);
    }
}
