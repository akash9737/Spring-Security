package com.akash.spring.security.service;

import com.akash.spring.security.dao.UserRepo;
import com.akash.spring.security.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailService implements UserDetailsService {


    private UserRepo repo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

       User user = repo.findByUsername(username);
       if(user==null)   {
           System.out.println("User 404");
           throw new UsernameNotFoundException("User 404");
       }


        return null;
    }
}
